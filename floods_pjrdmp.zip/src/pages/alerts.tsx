import React from 'react';
import Alerts from '../Alerts';

function AlertsPage() {
  return (
      <Alerts />
  );
}

export default AlertsPage;
