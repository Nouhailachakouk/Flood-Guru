import React from 'react';
import Emergency from '../Emergency';

function EmergencyPage() {
  return (
      <Emergency />
  );
}

export default EmergencyPage;
