import React from 'react';
import SafetyGuidelines from '../Safety-Guidelines';

function SafetyGuidelinesPage() {
  return (
      <SafetyGuidelines />
  );
}

export default SafetyGuidelinesPage;
